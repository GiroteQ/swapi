export const querykeys = {
  people: "people",
  selectedChar: "selectedCharacter"
}